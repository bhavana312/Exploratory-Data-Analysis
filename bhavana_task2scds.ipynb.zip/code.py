import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder

try:
    df = pd.read_csv("dataset1.csv")
except FileNotFoundError:
    print("Error: dataset1.csv not found. Please make sure the file is in the correct directory.")
    exit()

print("=== Original DataFrame Info ===")
df.info()

categorical_cols = df.select_dtypes(include=['object', 'category']).columns
print("\n=== Categorical Variables ===")
print(list(categorical_cols))

df_encoded = df.copy()

print("\n=== Encoding Categorical Variables (Label Encoding) ===")
label_encoders = {}
for col in categorical_cols:
    if col != 'Unique ID':
        label_encoders[col] = LabelEncoder()
        df_encoded[col] = df_encoded[col].fillna('Missing')
        df_encoded[col] = label_encoders[col].fit_transform(df_encoded[col])
        print(f"Encoded '{col}'")

print("\n=== DataFrame after Label Encoding (First 5 Rows) ===")
print(df_encoded.head())

def detect_outliers_iqr(data, column):
    if pd.api.types.is_numeric_dtype(data[column]):
        Q1 = data[column].quantile(0.25)
        Q3 = data[column].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        outliers = data[(data[column] < lower_bound) | (data[column] > upper_bound)]
        return outliers
    else:
        return pd.DataFrame()

print("\n=== Outliers Detected by Country (Using IQR) ===")
numeric_cols_encoded = df_encoded.select_dtypes(include=[np.number]).columns.tolist()
if 'Unique ID' in numeric_cols_encoded:
    numeric_cols_encoded.remove('Unique ID')

if 'Country' in df.columns:
    for country in df['Country'].dropna().unique():
        print(f"\n--- Country: {country} ---")
        idx = df['Country'] == country
        country_df = df_encoded[idx].copy()
        for col in numeric_cols_encoded:
            outliers = detect_outliers_iqr(country_df, col)
            if not outliers.empty:
                print(f"Outliers in '{col}' for {country}:")
                if 'Unique ID' in df.columns:
                    print(df.loc[outliers.index, ['Unique ID', col]])
                else:
                    print(outliers[[col]])
else:
    print("\n'Country' column not found in the dataframe. Skipping outlier detection by country.")

print("\n=== Histograms for Numerical Variables ===")
numeric_cols_hist = df_encoded.select_dtypes(include=[np.number]).columns
numeric_cols_hist = numeric_cols_hist.drop('Unique ID', errors='ignore')

if not numeric_cols_hist.empty:
    df_encoded[numeric_cols_hist].hist(figsize=(15, 10), bins=20)
    plt.tight_layout()
    plt.show()
else:
    print("No numerical columns found for plotting histograms.")

print("\n=== Basic EDA ===")
print("\nDataFrame Description:")
print(df_encoded.describe())

print("\nDataFrame Info:")
df_encoded.info()

print("\nValue Counts for Selected Categorical (now Encoded) Columns:")
for col in ['Country', 'Gender', 'Education Status', 'Marital Status']:
    if col in df_encoded.columns:
        print(f"\nValue Counts for '{col}':")
        print(df_encoded[col].value_counts())

print("\n=== Correlation Analysis (using Encoded DataFrame) ===")
correlation_matrix = df_encoded[numeric_cols_encoded].corr()

print("\nCorrelation Matrix:")
print(correlation_matrix)

plt.figure(figsize=(12, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix of Numerical Variables (Encoded)')
plt.show() # type: ignore